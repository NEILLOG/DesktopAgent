"""檢查素材型角色的 sprite sheet（只用標準函式庫）。

用法：python3 check_sprites.py <角色資料夾> [--cell 280] [--unit 10] [--min-gap 10] [--palette-from 圖檔]
  --palette-from：用某張 PNG 裡出現的顏色當調色盤（例如原始參考圖）；不給就用柯基的調色盤

檢查項目：
  1. 每格內容離左、上、右邊緣的最小距離（px），必須 >= MIN_GAP
  2. 邏輯像素對齊：每個 10x10 區塊內的像素必須完全相同
  3. 沒有半透明像素（alpha 只能是 0 或 255）
  4. 顏色都在調色盤內
"""
import json
import os
import struct
import sys
import zlib

CELL = 280
UNIT = 10
MIN_GAP = 10
PALETTE = {
    (59, 42, 32), (232, 147, 58), (196, 115, 42), (255, 244, 230), (230, 214, 194),
    (242, 167, 160), (43, 29, 20), (255, 255, 255), (247, 170, 150), (242, 181, 68),
    (111, 160, 240), (150, 160, 180),
}


def read_png(path):
    with open(path, 'rb') as f:
        data = f.read()
    if data[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('not a PNG')
    pos, idat = 8, b''
    while pos < len(data):
        length, = struct.unpack('>I', data[pos:pos + 4])
        ctype = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + length]
        if ctype == b'IHDR':
            w, h, depth, color, _, _, interlace = struct.unpack('>IIBBBBB', body)
        elif ctype == b'IDAT':
            idat += body
        pos += 12 + length
    if depth != 8 or interlace != 0 or color not in (2, 6):
        raise ValueError(f'unsupported PNG (depth={depth}, color={color}, interlace={interlace})')
    bpp = 4 if color == 6 else 3
    raw = zlib.decompress(idat)
    stride = w * bpp
    rows, prev, i = [], bytearray(stride), 0
    for _ in range(h):
        ft = raw[i]; i += 1
        line = bytearray(raw[i:i + stride]); i += stride
        for x in range(stride):
            a = line[x - bpp] if x >= bpp else 0
            b = prev[x]
            c = prev[x - bpp] if x >= bpp else 0
            if ft == 1:
                line[x] = (line[x] + a) & 255
            elif ft == 2:
                line[x] = (line[x] + b) & 255
            elif ft == 3:
                line[x] = (line[x] + ((a + b) >> 1)) & 255
            elif ft == 4:
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pr = a if pa <= pb and pa <= pc else (b if pb <= pc else c)
                line[x] = (line[x] + pr) & 255
        rows.append(bytes(line))
        prev = line

    def px(x, y):
        o = x * bpp
        r = rows[y]
        return (r[o], r[o + 1], r[o + 2], r[o + 3] if bpp == 4 else 255)
    return w, h, px


def palette_from(path):
    w, h, px = read_png(path)
    return {px(x, y)[:3] for y in range(h) for x in range(w) if px(x, y)[3] == 255}


def check(folder):
    manifest = json.load(open(os.path.join(folder, 'manifest.json'), encoding='utf-8'))
    ok = True
    print(f"{'動畫':<14}{'格':>3}  {'左':>4}{'上':>5}{'右':>5}  問題")
    for name, a in manifest['animations'].items():
        w, h, px = read_png(os.path.join(folder, a['source']))
        cols = a['columns']
        rows_n = (a['frames'] + cols - 1) // cols
        if (w, h) != (cols * CELL, rows_n * CELL):
            print(f'{name}: 圖片尺寸 {w}x{h} 與 manifest 不符'); ok = False
        for n in range(a['frames']):
            ox, oy = (n % cols) * CELL, (n // cols) * CELL
            minx = miny = CELL; maxx = -1
            issues = set()
            for by in range(0, CELL, UNIT):
                for bx in range(0, CELL, UNIT):
                    first = px(ox + bx, oy + by)
                    for yy in range(UNIT):
                        for xx in range(UNIT):
                            if px(ox + bx + xx, oy + by + yy) != first:
                                issues.add('未對齊 10px')
                    if first[3] not in (0, 255):
                        issues.add('半透明')
                    if first[3] == 0:
                        continue
                    if first[:3] not in PALETTE:
                        issues.add(f'新顏色 {first[:3]}')
                    minx = min(minx, bx); miny = min(miny, by); maxx = max(maxx, bx + UNIT - 1)
            if maxx < 0:
                print(f'{name:<14}{n + 1:>3}  （空格）'); continue
            left, top, right = minx, miny, CELL - 1 - maxx
            if min(left, top, right) < MIN_GAP:
                issues.add('太靠邊')
            if issues:
                ok = False
            flag = '、'.join(sorted(issues)) if issues else ''
            print(f'{name:<14}{n + 1:>3}  {left:>4}{top:>5}{right:>5}  {flag}')
    print('\n結果：' + ('全部通過' if ok else '有問題'))
    return ok


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('folder')
    ap.add_argument('--cell', type=int, default=CELL)
    ap.add_argument('--unit', type=int, default=UNIT)
    ap.add_argument('--min-gap', type=int, default=MIN_GAP)
    ap.add_argument('--palette-from')
    a = ap.parse_args()
    CELL, UNIT, MIN_GAP = a.cell, a.unit, a.min_gap
    if a.palette_from:
        PALETTE = palette_from(a.palette_from)
    sys.exit(0 if check(a.folder) else 1)
