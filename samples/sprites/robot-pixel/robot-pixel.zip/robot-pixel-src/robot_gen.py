"""機器人像素角色產生器。

來源：src/robot_ref_48.png（同事提供的 8x4 表情表，已還原成原生解析度，每個表情 48x48 邏輯像素）
輸出：sprites/robot-pixel/（manifest.json、preview.png、各動畫 sprite sheet）

原圖完全不重畫，只做三件事：挑選表情、排序成動畫、必要時把兩個表情的局部合成一格。
"""
import json
import os
import sys
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'src', 'robot_ref_48.png')
OUT = os.path.join(HERE, 'sprites', 'robot-pixel')

G = 48          # 原生網格
SCALE = 6       # 每個邏輯像素 6x6 px → 每格 288 px
DROP = 6        # 原圖底部留白 6 列，往下移讓底座貼齊格子底邊

sheet = Image.open(SRC).convert('RGBA')
ICON = [sheet.crop((c * G, r * G, c * G + G, r * G + G)) for r in range(4) for c in range(8)]

ANTENNA = (22, 4, 26, 9)   # #3 的天線亮點所在區域


def face(n, antenna_from=None, dx=0):
    """取第 n 號表情；antenna_from 指定時，天線改用另一個表情的；dx 為整體水平位移。"""
    im = ICON[n].copy()
    if antenna_from is not None:
        im.paste(ICON[antenna_from].crop(ANTENNA), ANTENNA[:2])
    out = Image.new('RGBA', (G, G), (0, 0, 0, 0))
    out.alpha_composite(im, (dx, DROP))
    return out


ANIMS = {
    # 名稱: (每格內容, columns, fps, loop, next/hold)
    'idle':         ([face(i) for i in (0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 2, 0)], 4, 6, True, None),
    'listening':    ([face(i) for i in (8, 9, 10, 9)], 4, 6, True, None),
    'transcribing': ([face(i) for i in (0, 4, 4, 4, 0, 6, 6, 6)], 4, 6, True, None),
    'thinking':     ([face(i) for i in (0, 31, 31, 26, 26, 26, 26, 26, 31, 0)], 5, 5, True, None),
    'tool':         ([face(1), face(1, antenna_from=3)], 2, 4, True, None),
    'streaming':    ([face(i) for i in (0, 15, 16, 17, 16, 15)], 6, 10, True, None),
    'done':         ([face(i) for i in (20, 21, 21, 21, 18, 19, 18, 19)], 4, 8, False, ('next', 'idle')),
    'attention':    ([face(i) for i in (22, 22, 22, 23)], 4, 6, True, None),
    'error':        ([face(i) for i in (27, 27, 24, 25, 24, 25)], 6, 6, False, ('hold', 'last')),
    'sleep':        ([face(i) for i in (2, 2, 7, 7)], 4, 2, True, None),
    'poke.press':   ([face(2), face(28)], 2, 12, False, ('hold', 'last')),
    'poke.release': ([face(i) for i in (29, 29, 29, 29, 18, 19, 18, 0)], 4, 10, False, ('next', 'idle')),
    'drag':         ([face(30, dx=d) for d in (-1, 0, 1, 0)], 4, 8, True, None),
}
FILES = {'poke.press': 'poke_press.png', 'poke.release': 'poke_rel.png'}

os.makedirs(OUT, exist_ok=True)
manifest_anims = {}
for name, (frames, cols, fps, loop, extra) in ANIMS.items():
    rows = (len(frames) + cols - 1) // cols
    cell = G * SCALE
    sh = Image.new('RGBA', (cols * cell, rows * cell), (0, 0, 0, 0))
    for i, f in enumerate(frames):
        sh.paste(f.resize((cell, cell), Image.NEAREST), ((i % cols) * cell, (i // cols) * cell))
    fn = FILES.get(name, name + '.png')
    sh.save(os.path.join(OUT, fn))
    entry = {'source': fn, 'frames': len(frames), 'columns': cols, 'fps': fps, 'loop': loop}
    if extra:
        entry[extra[0]] = extra[1]
    manifest_anims[name] = entry

face(0).resize((G * SCALE, G * SCALE), Image.NEAREST).save(os.path.join(OUT, 'preview.png'))

manifest = {
    "schemaVersion": 1,
    "id": "neillog.robot-pixel",
    "name": "機器人（像素）",
    "author": "張仲毅",
    "version": "0.1.0",
    "kind": "frames",
    "box": {"width": 96, "height": 96},
    "effectMargin": 0,
    "hitShape": "rect",
    "bubbleAnchor": {"x": 0.5, "y": 0.16},
    "voice": "語氣簡潔、帶點機械感，偶爾用「嗶」開頭。",
    "rendering": "pixelated",
    "animations": manifest_anims,
}
with open(os.path.join(OUT, 'manifest.json'), 'w', encoding='utf-8') as fp:
    json.dump(manifest, fp, ensure_ascii=False, indent=2)
print('ok', list(ANIMS))
